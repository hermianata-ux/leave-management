
package com.organization.leavemanagement;

import com.organization.leavemanagement.model.*;
import com.organization.leavemanagement.repository.*;
import com.organization.leavemanagement.service.*;
//import com.organization.leavemanagement.exception.*;

public class LeaveManagement {

    public static void main(String[] args) {

        EmployeeRepository empRepo = new EmployeeRepository();
        LeaveRepository leaveRepo = new LeaveRepository();

        Employee emp = new PermanentEmployee("E101", "John", 25);
        empRepo.save(emp);

        LeavePolicy policy = new SickLeavePolicy();
         
        LeaveService service = new LeaveService(empRepo,policy,leaveRepo);
        LeaveRequest request = new LeaveRequest(emp, LeaveType.SICK, 3, "Fever");

        try {
            service.applyLeave(request);
            System.out.println("Status: " + request.getStatus());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}