
package com.organization.leavemanagement.execption;


public class InsufficientLeaveBalanceException extends RuntimeException 
{
    public InsufficientLeaveBalanceException(String message) 
    {
        super(message);
    }
}
