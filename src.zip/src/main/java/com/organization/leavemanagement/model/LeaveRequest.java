
package com.organization.leavemanagement.model;

import java.time.LocalDate;

public class LeaveRequest {

     public Employee employee;   
    public LeaveType leaveType;
    public int numberOfDays;
    public String reason;
    public LocalDate requestDate;
    public LeaveStatus status;

    public LeaveRequest(Employee employee,
                        LeaveType leaveType,
                        int numberOfDays,
                        String reason) 
    {
        this.employee = employee;
        this.leaveType = leaveType;
        this.numberOfDays = numberOfDays;
        this.reason = reason;
        this.requestDate = LocalDate.now();
        this.status = LeaveStatus.PENDING;
    }

    public Employee getEmployee() { 
        return employee; 
    }
    public LeaveType getLeaveType() {
        return leaveType; 
    }
    public int getNumberOfDays() { 
        return numberOfDays; 
    }
    public String getReason() { 
        return reason;
    }
    public LeaveStatus getStatus() { 
        return status; 
    }

    public void setStatus(LeaveStatus status) {
        this.status = status;
    }
}