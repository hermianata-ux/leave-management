
package com.organization.leavemanagement.service;


import com.organization.leavemanagement.execption.InvalidLeaveRequestException;
import com.organization.leavemanagement.model.Employee;
import com.organization.leavemanagement.model.LeaveRequest;

public class CasualLeavePolicy implements LeavePolicy {

    @Override
    public void validateLeave(Employee employee, LeaveRequest request) {
        if (request.getNumberOfDays() > 5) {
            throw new InvalidLeaveRequestException("Max 5 casual leaves at a time");
        }
    }
}
