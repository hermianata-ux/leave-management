
package com.organization.leavemanagement.service;

import com.organization.leavemanagement.execption.InvalidLeaveRequestException;
import com.organization.leavemanagement.model.Employee;
import com.organization.leavemanagement.model.LeaveRequest;

public class EarnedLeavePolicy implements LeavePolicy {

    @Override
    public void validateLeave(Employee employee, LeaveRequest request) {
        if (request.getNumberOfDays() > 10) {
            throw new InvalidLeaveRequestException("Max 10 earned leaves at a time");
        }
    }
}
