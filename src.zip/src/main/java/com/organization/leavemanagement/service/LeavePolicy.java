
package com.organization.leavemanagement.service;

import com.organization.leavemanagement.model.Employee;
import com.organization.leavemanagement.model.LeaveRequest;

public interface LeavePolicy {
    void validateLeave(Employee employee, LeaveRequest request);
}
