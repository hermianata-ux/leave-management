
package com.organization.leavemanagement.service;


import com.organization.leavemanagement.execption.EmployeeNotFoundException;
import com.organization.leavemanagement.execption.InsufficientLeaveBalanceException;
import com.organization.leavemanagement.execption.InvalidLeaveRequestException;
import com.organization.leavemanagement.model.*;
import com.organization.leavemanagement.repository.*;
import com.organization.leavemanagement.util.ValidationUtil;

public class LeaveService {

    public EmployeeRepository employeeRepo;
    public LeaveRepository leaveRepo;
    public LeavePolicy leavePolicy;  
    public EmployeeRepository empRepo;
public LeaveService() {}
    public LeaveService(EmployeeRepository employeeRepo,LeavePolicy policy, LeaveRepository leaveRepo) {
        this.employeeRepo = empRepo;
        this.leaveRepo = leaveRepo;
        this.leavePolicy = policy;
    }

    public void applyLeave(LeaveRequest request) {

        ValidationUtil.validateString(request.getReason(), "Reason");
        ValidationUtil.validatePositive(request.getNumberOfDays(), "Leave Days");
        ValidationUtil.validateEnum(request.getLeaveType(), "Leave Type");

        Employee employee = employeeRepo.findById(request.getEmployee().getEmployeeId());

        if (employee == null) {
            throw new EmployeeNotFoundException("Employee not found");
        }

        if (request.getNumberOfDays() > employee.getLeaveBalance()) {
            throw new InsufficientLeaveBalanceException("Insufficient balance");
        }

        if (employee.getTotalLeaveTakenThisYear() +
                request.getNumberOfDays()
                > employee.calculateMaxAllowedLeave()) {

            throw new InvalidLeaveRequestException("Exceeded yearly leave limit");
        }

        leavePolicy.validateLeave(employee, request);

        employee.deductLeave(request.getNumberOfDays());

        request.setStatus(LeaveStatus.APPROVED);

        leaveRepo.save(request);
    }
}