
package com.organization.leavemanagement.util;



import com.organization.leavemanagement.execption.InvalidLeaveRequestException;

public class ValidationUtil {

    
    public static void validateString(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            throw new InvalidLeaveRequestException(fieldName + " cannot be blank");
        }
    }

    
    public static void validatePositiveNumber(int number, String fieldName) {
        if (number <= 0) {
            throw new InvalidLeaveRequestException(fieldName + " must be greater than 0");
        }
    }

    
    public static void validateEnum(Object enumValue, String fieldName) {
        if (enumValue == null) {
            throw new InvalidLeaveRequestException(fieldName + " must be valid");
        }
    }

    public static void validatePositive(int numberOfDays, String leave_Days) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}